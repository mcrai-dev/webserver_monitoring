import os

def ping(host):
    ip_list = [host]
    for ip in ip_list:
        response = os. popen(f"ping {ip}"). read()
    return response
